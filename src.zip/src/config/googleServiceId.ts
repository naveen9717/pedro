// export default {
//   webClientId:
//     '147013063536-2tq65e5fm6igh52rciffa5nj86n7m9bt.apps.googleusercontent.com',
// };

export default {
  webClientId:
    '477823304300-a7csqro4lf1it6kg99iru5gvqb4shpv0.apps.googleusercontent.com',
};
