import {baseUrl} from '../service/utils/urls';

export const userApi = {
  Usuario: 'APP_CPFL',
  Senha: baseUrl.env === 'prod' ? '&tRu!N5k@9Apc' : 'Nh(#BIbAxW]Al7p11',
};
