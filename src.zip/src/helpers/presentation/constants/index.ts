export const ErrorFieldType = {
  REQUIRED_FIELD: 'Campo obrigatório.',
  IVALID_EMAIL_FORMAT: 'Formato de email inválido.',
  PHONE_FIELD_LEAST_DIGITS: 'Campo telefone deve conter 11 dígitos.',
};
