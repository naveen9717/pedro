export type LoginUrlDataReducer = {
  encrypt: string;
  clientId: string;
  internetGratis: string;
  instLength: number;
};
