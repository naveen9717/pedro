import {RegistrationTypeData} from '../components/registration/registrationData';

export type RegistrationTypeReducer = {
  regType: RegistrationTypeData;
};
