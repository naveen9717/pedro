export type DataInputType =
  | 'cpf'
  | 'cnpj'
  | 'cpf-cnpj'
  | 'phone'
  | 'zipCode'
  | 'date'
  | null;
