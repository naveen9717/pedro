export type TokenLegadoResponse = {
  cryptToken: string;
  token: string;
};
