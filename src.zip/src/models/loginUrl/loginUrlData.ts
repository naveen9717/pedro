import {LoginUrlDataReducer} from '../reducer/loginUrl';

export type LoginUrlData = LoginUrlDataReducer;
